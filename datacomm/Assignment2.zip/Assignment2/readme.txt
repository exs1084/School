Some ports(1980 being one) seem to cause issues when attempting to connect to them. 
I am assuming this is the ports themselves being reserved for some use, but the program blocks when trying to read from them after connecting.
Most likely this is that the program has connected to a socket used by something other than another peerchat?