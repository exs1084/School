filename = fullfile('testData.csv');
T = readtable(filename);
fileid=fopen('hw05_Sodergren_Erikson_MyClassifications.csv', 'w');
